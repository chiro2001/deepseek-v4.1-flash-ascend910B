# DP2/TP4 v4 init-only switch evidence

## Stage and switch

- Target CID: `b1aa15d8800346aff8f755a049feaae148b9d6e315e92bd32dcdf1063b429eb0`; no container restart.
- v4 package: `/work/dp_matrix_20261013_dp2tp4_v4`; archive SHA-256 `2e4f5cf5a58010cac18b42a27f21095f4aa041633fe56244989a790f32a9da3c`, `launch.sh` SHA-256 `97eaafdc2eab072c5ae4f725e124edef26b59fc5f545f691891f6850ba97c5ce`. Archive contents all pass `package_files.sha256`; `bash -n launch.sh` passes. Native source guards match the live container sources.
- Prepared plan identity: model `dsv41-dp-dp2tp4-v4`, DP2/TP4/DCP1/EP8, utilization .85, automatic KV, max length 196608, runtime fingerprint `9ab89d2d754ee6cdf8608a5854f851c696cc58cc8e9bcc467dbb3b40a340c076`. OPP path exists; `version.info` says compiler 9.0.0.
- Client-v2 archive SHA `082543ba23c96f91b60a089bdf049640d34ffdefac715d70470fb8a250bbf8f0` and frozen manifest + all 8 gzip hashes verified under `/work/dp_matrix_client_20261013_cl2`. CPU-only frozen-input proof passes. Client-v2 was not executed.
- v3 was stopped once with SIGTERM to the freshly verified API container PID 1902193 at `2026-10-13T08:16:58Z`; d24d `run.exit=0`, port listener cleared, NPU4–7 had no processes and chips 8–15 returned to ~2.8–3.1 GiB. NPU0–7/external processes were not touched.

## Single v4 initialization attempt

- The unique d24h launch started at about `2026-10-13T08:19:41Z`; no HTTP request was sent.
- `d24h/run.exit=1`. `service_selection.json` shows SID `ba3bf56f955347aba3f890a32575b669`, runtime fingerprint `64bcdd65103ff249fa21ee293af46fb5b87e96accf9964394961b4f6f3fd18b1`, `engine_initialized=false`, `ASGI_startup_completed=false`, zero rank and capacity descriptions. Runtime fingerprint differs from the prepared-plan fingerprint only alongside the runtime `DP_MATRIX_RUNTIME` environment entry and actual native guards being added to the service plan; compare `d24h/service/plan.json` to the prepared plan before any new launch.
- First specific worker failure: `Worker_DP1_TP0_EP4`, container PID 2169828 (rank 4, expected physical chip 12). Its worker log starts model loading at 08:21:52 and records `WorkerProc was terminated` at 08:23:26, without an inner Python exception. EngineCore_DP1 PID 2169783 then reports failed worker initialization; executor shutdown emits SIGTERM/SIGKILL for remaining workers. Other ranks later log `BrokenPipeError` while sending readiness after the parent failed; these are downstream shutdown errors.
- No post-load `dp_describe`, capacity helper, phase-proof, ASGI ready, or API identity was reached. No canary, generation, arm, metrics, or retry was run against v4.
- Target-container cgroup stats: `memory_limit=0`, `memory.failcnt=0`, `oom_kill=1`; the counter has no timestamp, so it cannot be attributed to this launch. Host `dmesg` is inaccessible (`Operation not permitted`); no cause beyond the terminated DP1 TP0 worker is proven.
- At 08:27:21, NPU4/6/7 had no processes, but NPU5 showed PID 1512132 / VLLMWorker_DP (~42.9 GiB). A later `/proc` check showed this PID was defunct, NSpid `1512132 2170048`, cgroup `/` (not the target CID); it was not signaled. At 08:35:39 no v4 API or EngineCore was present; the container itself remains running. No cleanup or retry followed.

Raw logs, `service_selection.json`, `plan.json`, `run.exit`, worker-specific Ascend logs, NPU/process snapshots, v3 stop evidence, and all staged hashes are included below. The copied d24h tree contains all regular files; the container's ephemeral Unix sockets under `d24h/tmp` were not copied.

`evidence.sha256` covers this directory (excluding itself); verify its own hash separately.
