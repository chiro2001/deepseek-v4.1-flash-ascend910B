# d24d runtime 只读取证

目标仅为 SSH alias `a3-21` 上的项目 CID `b1aa15d8800346aff8f755a049feaae148b9d6e315e92bd32dcdf1063b429eb0`；未重启容器、未触碰 0–7、未操作外部 CID、未清缓存。

## Ready 身份与路由

- 本地冻结实现定义 `GET /dp/identity`、`GET /dp/status`、`GET /dp/metrics`；旧 `/delivery/*` 前缀不正确。
- `GET /dp/identity`、`GET /dp/status`、`GET /v1/models` 均为 HTTP 200；identity/status/model 的原始 HTTP 回应及 body 分别保存在 `identity.http`/`identity.json`、`status.http`/`status.json`、`models.http`/`models.json`。
- 服务身份：SID `a77dcfc1c52346749bd7c2fce76638da`，served model `dsv41-dp-dp2tp4-v3`，layout `dp2-tp4`，runtime fingerprint `c160fc637cc3305cdf92a2a614a5b3595fbf619e8074393238109ef33aa1ad38`。`engine_initialized=true`、`ASGI_startup_completed=true`。
- `service_started=false`、`actual_kv_capacity_observed=false`、`actual_quality_passed=false`、`actual_performance_observed=false` 是 selection 中仍为 false 的字段；不要用它们宣称质量/性能或逻辑容量门已通过。
- 只进行了 GET 诊断和只读文件/PID/NPU 查询；未发送 generation、未调用 `/dp/arm` 或 `/dp/metrics`。
- Fresh 复核（2026-10-13 07:45–07:46 UTC）再次得到同一 SID/fingerprint、service PID 1902193 和 8 worker PID；fresh HTTP 原件为 `fresh-identity.*`、`fresh-status.*`、`fresh-models.*`。
- Fresh port ownership：容器内 `/proc/net/tcp` 的 `127.0.0.1:18960` LISTEN inode `32182631`，容器 PID `1902193` 的 fd 10 指向该 socket；宿主 PID `932020` 的 `NSpid=932020 1902193`，cgroup 为目标 CID。见 `fresh-port-owner.txt`。
- Fresh NPU snapshot 与 worker NSpid/cgroup 在 `fresh-npu-smi.info`、`fresh-worker.nspid-cgroup.txt`；NPU 4–7 的 8 个 worker PID 仍一一对应物理 chip 8–15，均在目标 CID cgroup。NPU 0–3 上观察到外部进程/高占用，未操作。

## 拓扑与实际 worker 映射

identity/status 均列出 8 个 worker；TP 组分别为 `[0,1,2,3]`、`[4,5,6,7]`，EP 组均为 `[0,1,2,3,4,5,6,7]`。两个 DP 各含 TP0–3，EP rank 分别 0–3、4–7，物理 chip 分别 8–11、12–15。identity 与 status worker PID 集合完全相同。

`worker.nspid-cgroup.txt` 将每个 host PID 的 `NSpid` 第二项对应回身份中的容器 PID，并确认 8 个进程的 cgroup 均为目标 CID。`npu-smi.info` 将 host PID 一一映射到物理 chip 8–15（NPU 4–7）。

## KV / graph 启动证据

- `d24d.run.log`：DP0 KV cache `849,714 tokens`，DP1 `849,648 tokens`；两者对 196,608-token 请求的 maximum concurrency 均为 `4.32x`。启动日志的 available KV cache 约 6.46–6.47 GiB。
- API capacity description 有 8 项，backing storage 约 6.46 GiB；`logical_token_capacity` 八项均为 null，`long_request_validated=false`。这不是长上下文/质量通过证据。
- 日志显示静态 kernel compile `141/142` 成功；八个 rank 均报告 draft capture metadata，identity 每个 worker 都报告 `draft_graph=true` 和 FULL draft wrapper。FULL decode capture 进度到 100%，两条 `Graph capturing finished` 行分别来自两个 DP 的 TP0 worker。
- `FORMAL_DSPARK_COUNTERS_INSTALLED` 共 8 条，但其 `actual_device_consumer_proof` 均为 false，不能据此宣称 device-consumer proof。

## Engram 口径

- `model.config.json` 的架构为 `DeepseekV41ForCausalLM`，`text_config.engram_layer_ids=[1,14]`；plan/identity 与 startup 参数均有 `additional_config.enable_engram=true`、`engram_storage=int8`。
- `V41_ENGRAM_DEVICE_INDEX='0'` 是布尔快路径开关值而非 NPU ordinal：目标 `model.py` 将其解析为 `_ENGRAM_DEVICE_INDEX=false`，所以关闭 device-index 快路径。`rank_descriptions.engram_device_index='0'` 是 `DeliveryWorker.delivery_describe()` 对各 worker `os.environ` 的回显。
- `FormalDSparkWorker.load_model()` 在 `super().load_model()` 后检查实际 `DeepseekV41Model` 数量为 1；八条 counter-installed 日志表明该检查之后启动流程继续完成。目标 `model.py` 的 `enable_engram` 分支构建 `NodeShardedEngram`，Engram loader 的 enable 分支检查 Engram 权重集合完整，否则抛错。相关目标容器源码和 SHA 在 `engram_model.py.excerpt`、`engram_weights.py.excerpt`、`runtime.worker.py.excerpt`、`delivery.worker.py.excerpt`、`engram-chain.sha256` 中。
- 但 `model.py` / `engram_hbm.py` 不在 identity 的 native source guard 集合；日志没有 `[DEVICE-INDEX]`/Engram 初始化行，也没有 Engram 对象或 tensor device 的 runtime RPC。因此可报告 Engram 配置与模型加载链证据，不得称直接对象/设备 consumer 证明。

完整原始文件、摘录、派生摘要及 SHA 清单见本目录；`evidence.sha256` 为文件清单，需单独校验其自身哈希。

## Canary staging 状态

根已批准的 client-v1 包与冻结输入源哈希匹配。`client.tgz`、manifest、8 个 gzip 已复制到远端主机新临时目录 `/home/l00886679/tmp/dsv41-dp-matrix-20261013/cl1`，但该主机目录不是目标 CID bind mount；从目标 CID读取同路径失败。首次 `docker cp` 尝试返回 daemon `invalid argument`。Canary 尚未启动、generation/arm 数为 0；未自动重试或继续到 DP0/DP1。client/输入文件的源 SHA 分别由 parent 给定并在本地验证，远端 staging 异常需先解决。
