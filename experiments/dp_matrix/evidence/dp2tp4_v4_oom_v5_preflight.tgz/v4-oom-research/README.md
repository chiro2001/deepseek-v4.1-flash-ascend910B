Read-only follow-up evidence for v4 NUMA/OOM research. Captured via SSH alias a3-21 against target CID b1aa15d8800346aff8f755a049feaae148b9d6e315e92bd32dcdf1063b429eb0.

Included: filtered and complete kernel OOM event; all-node NUMA and cgroup snapshots; installed vLLM/Ascend NUMA-source context and SHA; CPU-only interleave syscall and v5 helper checks; v5/cl4 staging verification; read-only NPU 8–15 process-to-container mapping and final recheck.

Safety result: v5 and cl4 were staged only; neither client nor service was run. No HTTP, model load, torch/torch_npu import, NPU allocation, cache operation, process signal, external container modification, or service readiness claim was made. The one final post-stage NPU recheck found physical NPU 8–15 still occupied by the separate running container recorded in `npu-final-recheck-20261013.txt`; no more polling is planned.
