#!/usr/bin/env python3
"""CPU-only, bounded Linux NUMA interleave permission probe.
No torch/torch_npu import, no NPU/runtime access, no device allocation.
"""
import ctypes
import os
import sys

SIZE = 1024 * 1024
PAGE = os.sysconf("SC_PAGE_SIZE")
libnuma = ctypes.CDLL("libnuma.so.1", use_errno=True)
get_mempolicy = libnuma.get_mempolicy
get_mempolicy.argtypes = [
    ctypes.POINTER(ctypes.c_int),
    ctypes.POINTER(ctypes.c_ulong),
    ctypes.c_ulong,
    ctypes.c_void_p,
    ctypes.c_ulong,
]
get_mempolicy.restype = ctypes.c_int

def policy(label):
    mode = ctypes.c_int(-1)
    mask = ctypes.c_ulong(0)
    ctypes.set_errno(0)
    rc = get_mempolicy(ctypes.byref(mode), ctypes.byref(mask), 64, None, 0)
    err = ctypes.get_errno()
    print(f"{label}: rc={rc} errno={err} mode={mode.value} mask=0x{mask.value:x}", flush=True)
    if rc != 0:
        raise OSError(err, os.strerror(err))

policy("before_cpu_touch")
libc = ctypes.CDLL(None, use_errno=True)
libc.mmap.restype = ctypes.c_void_p
libc.mmap.argtypes = [
    ctypes.c_void_p,
    ctypes.c_size_t,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_long,
]
PROT_READ, PROT_WRITE = 1, 2
MAP_PRIVATE, MAP_ANONYMOUS = 2, 0x20
addr = libc.mmap(None, SIZE, PROT_READ | PROT_WRITE,
                 MAP_PRIVATE | MAP_ANONYMOUS, -1, 0)
if addr == ctypes.c_void_p(-1).value:
    err = ctypes.get_errno()
    raise OSError(err, os.strerror(err))
base = ctypes.cast(addr, ctypes.c_void_p).value
for offset in range(0, SIZE, PAGE):
    ctypes.c_ubyte.from_address(base + offset).value = 1
print(f"cpu_mapping_bytes={SIZE} page_size={PAGE}", flush=True)

map_start = None
with open("/proc/self/maps", "r") as f:
    for line in f:
        bounds = line.split(None, 1)[0]
        lo, hi = (int(x, 16) for x in bounds.split("-", 1))
        if lo <= base < hi:
            map_start = bounds.split("-", 1)[0]
            break
if map_start is None:
    print("numa_maps_entry=not_found", flush=True)
else:
    with open("/proc/self/numa_maps", "r") as f:
        for line in f:
            if line.startswith(map_start):
                print("numa_maps_entry=" + line.rstrip(), flush=True)
                break

policy("after_cpu_touch")
libc.munmap.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
libc.munmap(ctypes.c_void_p(base), SIZE)
print("cpu_mapping_unmapped=true; process will exit naturally", flush=True)
