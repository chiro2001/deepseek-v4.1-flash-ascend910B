import json
import sys

sys.path.insert(0, "/work/dp_matrix_20261013_dp2tp4_v5")
from dp_matrix.host_memory import verify_interleave

result = verify_interleave("0,1,2,3")
forbidden = sorted(
    name for name in ("torch", "torch_npu", "vllm", "vllm_ascend")
    if name in sys.modules
)
print(json.dumps({
    "result": result,
    "forbidden_modules_loaded": forbidden,
    "python_no_site": True,
}, sort_keys=True), flush=True)
if forbidden:
    raise SystemExit(9)
