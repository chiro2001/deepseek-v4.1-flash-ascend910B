# DP0 canary failure receipt

- Target CID only: `b1aa15d8800346aff8f755a049feaae148b9d6e315e92bd32dcdf1063b429eb0`; service SID `a77dcfc1c52346749bd7c2fce76638da`, runtime fingerprint `c160fc637cc3305cdf92a2a614a5b3595fbf619e8074393238109ef33aa1ad38`.
- Only DP0 ran. DP1 did not run; no retry, no second generation, and no additional arm/metrics call was made after the client failed.
- Exact receipt is `dp0.json` (copied byte-for-byte from `/work/dp_matrix_client_20261013_cl1/run/canary/dp0.json`); pre-request identity is `identity_before.json`. The remote canary directory had only these two files when archived; no `dp1.json`, `identity_after.json`, or `result.json` exists because the client aborted.
- Client reduction error: `ValueError: Every actual TP rank must dispatch real draft graphs, without eager fallback`. The generation itself completed: HTTP 200, correct DP rank 0, full `[DONE]`, finish reason `length`, usage 2,048 prompt + 256 completion = 2,304 total, cleanliness PASS. Output text is preserved only in the private receipt; summary is 393 characters, SHA-256 `2e1d3a4dec0d9cd99474dbfb540841f9694dea05d737fef422f29199520f7868`.
- `/dp/metrics` **was fetched** and returned trusted metrics. Each DP0 TP rank (TP0–3, chips 8–11) reported 135 decode rounds, 135 draft-graph calls, and 1 eager draft call; prefill calls=1. The client reducer set `reduction=null` and recorded the error above. This is not a server HTTP error: service log has HTTP 200 for DP0 `/dp/arm`, `/v1/chat/completions`, and `/dp/metrics`, with no server traceback/error stack for this request.
- Post-failure read-only `/dp/status` confirmed no pending/sample-pending work; DP0 retained the completed request ID, while DP1 has no request IDs. Service identity stayed ready and unchanged. `postfailure.*` captures identity/status, NPU mapping, worker NSpid/cgroup, and port owner.
- Complete post-failure d24d service log was separately captured as `postfailure-final.d24d.run.log`; it does not overwrite the pre-canary log in the adjacent site-runtime audit directory.
- No formal benchmark, quality suite, DP1 request, service restart, or v3 package change followed this failure.

`evidence.sha256` hashes every local receipt/status/log file in this directory; verify its own SHA separately.
